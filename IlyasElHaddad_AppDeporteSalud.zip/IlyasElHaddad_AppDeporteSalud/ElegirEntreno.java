import java.awt.*;
import javax.swing.*;

public class ElegirEntreno extends JFrame {

    private Entrenamiento seleccionado;
    private JLabel lblResumen;
    private JComboBox<String> comboHorario;
    private JButton btnConfirmar;
    private JButton btnVolver;

    public ElegirEntreno(Entrenamiento e) {
        this.seleccionado = e;
        initComponentsGridBag();
        setSize(420, 260);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    private void initComponentsGridBag() {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        lblResumen = new JLabel(seleccionado.toString());
        lblResumen.setPreferredSize(new Dimension(360, 60));

        comboHorario = new JComboBox<>();
        comboHorario.addItem("Mañana 07:00");
        comboHorario.addItem("Mediodía 12:00");
        comboHorario.addItem("Tarde 18:00");
        comboHorario.addItem("Noche 21:00");

        btnConfirmar = new JButton("Confirmar");
        btnConfirmar.addActionListener(e -> confirmar());

        btnVolver = new JButton("Volver");
        btnVolver.addActionListener(e -> dispose());

        c.insets = new Insets(8,8,8,8);
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2; c.fill = GridBagConstraints.HORIZONTAL;
        add(lblResumen, c);

        c.gridwidth = 1; c.gridy = 1; c.gridx = 0; c.weightx = 0.3;
        add(new JLabel("Horario:"), c);
        c.gridx = 1; c.weightx = 0.7; c.fill = GridBagConstraints.HORIZONTAL;
        add(comboHorario, c);

        c.gridy = 2; c.gridx = 0; c.weightx = 0.5; c.fill = GridBagConstraints.NONE;
        add(btnConfirmar, c);
        c.gridx = 1;
        add(btnVolver, c);
    }

    private void confirmar() {
        String horario = (String) comboHorario.getSelectedItem();
        String mensaje = String.format("Entrenamiento confirmado:\n%s\nHorario: %s",
                seleccionado.toString(), horario);
        JOptionPane.showMessageDialog(this, mensaje);
        dispose();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jComboBox1 = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridBagLayout());

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Intenso", "Moderado", "Relajado", "Mixto" }));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.ipadx = 9;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 18, 0, 137);
        getContentPane().add(jComboBox1, gridBagConstraints);

        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(jList1);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 82;
        gridBagConstraints.ipady = 130;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(6, 49, 0, 0);
        getContentPane().add(jScrollPane1, gridBagConstraints);

        jButton1.setText("CONFIRMAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 49, 45, 0);
        getContentPane().add(jButton1, gridBagConstraints);

        jButton2.setText("VOLVER");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.ipadx = 26;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 18, 45, 137);
        getContentPane().add(jButton2, gridBagConstraints);

        jLabel1.setText("Elige tu tipo de entrenamiento");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.ipadx = 54;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(46, 49, 0, 137);
        getContentPane().add(jLabel1, gridBagConstraints);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
    }//GEN-LAST:event_jButton2ActionPerformed
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JList<String> jList1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
