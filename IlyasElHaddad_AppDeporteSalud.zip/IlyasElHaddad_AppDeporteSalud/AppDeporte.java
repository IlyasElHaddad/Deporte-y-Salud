import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.util.ArrayList;
import javax.swing.*;

public class AppDeporte extends JFrame {

    private JPanel panelIzquierda;
    private JPanel panelCentro;
    private JPanel panelDerecha;
    private JComboBox<String> comboFiltro;
    private DefaultListModel<Entrenamiento> modeloLista;
    private JList<Entrenamiento> listaEntrenos;
    private JButton btnElegir;
    private JButton btnSalir;
    private JLabel lblImagenLocal;
    private JLabel lblImagenInternet;

    private java.util.List<Entrenamiento> lista = new ArrayList<>();

    public AppDeporte() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 520);
        setLocationRelativeTo(null);
        cargarDatos();
        initgridbag();
    }

    private void cargarDatos() {
        lista.add(new Entrenamiento("HIIT", "Intenso", 30, 450));
        lista.add(new Entrenamiento("Cardio suave", "Relajado", 45, 300));
        lista.add(new Entrenamiento("Fuerza pierna", "Moderado", 50, 400));
        lista.add(new Entrenamiento("Core", "Mixto", 25, 180));
        lista.add(new Entrenamiento("Spinning", "Intenso", 40, 500));
        lista.add(new Entrenamiento("Yoga Vinyasa", "Relajado", 60, 220));
    }

    private void initgridbag() {
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        panelIzquierda = new JPanel(new BorderLayout());
        lblImagenLocal = new JLabel("", SwingConstants.CENTER);
        ImagenLocal("/img/Deporte.png", lblImagenLocal);
        panelIzquierda.add(lblImagenLocal, BorderLayout.CENTER);

        panelDerecha = new JPanel(new BorderLayout());
        lblImagenInternet = new JLabel("",SwingConstants.CENTER);
        ImagenInternet("https://previews.123rf.com/images/oksancia/oksancia1212/oksancia121200168/16759357-sports-balls-vertical-seamless-pattern-background-border.jpg", lblImagenInternet);
        panelDerecha.add(lblImagenInternet, BorderLayout.CENTER);


        panelCentro = new JPanel(new GridBagLayout());
        GridBagConstraints b = new GridBagConstraints();

        comboFiltro = new JComboBox<>();
        comboFiltro.addItem("Todos");
        comboFiltro.addItem("Intenso");
        comboFiltro.addItem("Moderado");
        comboFiltro.addItem("Relajado");
        comboFiltro.addItem("Mixto");

        modeloLista = new DefaultListModel<>();
        listaEntrenos = new JList<>(modeloLista);
        JScrollPane scrollLista = new JScrollPane(listaEntrenos);
        scrollLista.setPreferredSize(new Dimension(250, 200));

        btnElegir = new JButton("Elegir entrenamiento");
        btnSalir = new JButton("Salir");

        comboFiltro.addActionListener(e -> actualizarLista());
        btnElegir.addActionListener(e -> abrirElegirEntreno());
        btnSalir.addActionListener(e -> dispose());

        b.insets = new Insets(10, 10, 10, 10);
        b.gridx = 0; b.gridy = 0;
        b.anchor = GridBagConstraints.WEST;
        panelCentro.add(new JLabel("Filtrar por intensidad:"), b);
        b.gridx = 1;
        b.fill = GridBagConstraints.HORIZONTAL;
        b.weightx = 1.0;
        panelCentro.add(comboFiltro, b);

        b.gridx = 0; b.gridy = 1; b.gridwidth = 2;
        b.fill = GridBagConstraints.BOTH;
        b.weightx = 1.0;  b.weighty = 1.0;
        panelCentro.add(scrollLista, b);

        b.gridy = 2; b.gridwidth = 1; b.weighty = 0;
        b.fill = GridBagConstraints.BOTH;
        b.weightx = 0.5;
        panelCentro.add(btnElegir, b);

        b.gridx = 1; b.weightx = 0.5;
        panelCentro.add(btnSalir, b);

        c.insets = new Insets(10,10, 10, 10);

        c.gridx = 0; c.gridy = 0; c.weightx = 0.3; c.weighty = 1.0;
        c.fill = GridBagConstraints.BOTH;
        getContentPane().add(panelIzquierda, c);

        c.gridx = 1; c.gridy = 0; c.weightx = 0.4;
        getContentPane().add(panelCentro, c);

        c.gridx = 2; c.gridy = 0; c.weightx = 0.3;
        getContentPane().add(panelDerecha, c);
        actualizarLista();
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                redimensionarImagen(lblImagenLocal);
                redimensionarImagen(lblImagenInternet);
                panelIzquierda.setPreferredSize(new Dimension(200, 200));
                lblImagenLocal.setPreferredSize(new Dimension(200, 200));
                panelDerecha.setPreferredSize(new Dimension(200, 200));
                lblImagenInternet.setPreferredSize(new Dimension(200, 200));}
        });
    }

    private void actualizarLista() {
        modeloLista.clear();
        String filtro = (String) comboFiltro.getSelectedItem();
        for (Entrenamiento e : lista) {
            if (filtro.equals("Todos") || e.getIntensidad().equalsIgnoreCase(filtro)) {
                modeloLista.addElement(e);
            }
        }
    }

    private void abrirElegirEntreno() {
        Entrenamiento e = listaEntrenos.getSelectedValue();
        if (e == null) {
            JOptionPane.showMessageDialog(this, "Selecciona un entrenamiento primero.");
            return;
        }
        ElegirEntreno ventana = new ElegirEntreno(e);
        ventana.setVisible(true);
    }

    private void ImagenLocal(String ruta, JLabel lbl) {
    try {java.net.URL imgUrl = getClass().getResource(ruta);
        if (imgUrl != null) {
            ImageIcon icon = new ImageIcon(imgUrl);
            lbl.setIcon(icon);
        } else {
            lbl.setText("No se encontró la imagen: " + ruta);
        }
    } catch (Exception ex) {}
    }
    private void ImagenInternet(String url, JLabel lbl) {
        new Thread(() -> {
            try {
                ImageIcon icon = new ImageIcon(new URL(url));
                SwingUtilities.invokeLater(() -> lbl.setIcon(icon));
            } catch (Exception ex) {}
        }).start();
    }

    private void redimensionarImagen(JLabel lbl) {
        Icon icono = lbl.getIcon();
        if (icono == null || !(icono instanceof ImageIcon)) return;

        Image img = ((ImageIcon) icono).getImage();
        int w = lbl.getWidth();
        int h = lbl.getHeight();
        if (w > 0 && h > 0) {
            Image escalada = img.getScaledInstance(w, h, Image.SCALE_SMOOTH);
            lbl.setIcon(new ImageIcon(escalada));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new AppDeporte().setVisible(true);
        });
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridBagLayout());

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 150, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 150, Short.MAX_VALUE)
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 150;
        gridBagConstraints.ipady = 150;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 6, 0, 0);
        getContentPane().add(jPanel1, gridBagConstraints);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 150, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 150, Short.MAX_VALUE)
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 150;
        gridBagConstraints.ipady = 150;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 6, 0, 6);
        getContentPane().add(jPanel2, gridBagConstraints);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.ipadx = 388;
        gridBagConstraints.ipady = 100;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(12, 6, 9, 6);
        getContentPane().add(jPanel3, gridBagConstraints);

        jButton1.setText("Clica");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 10, 0, 0);
        getContentPane().add(jButton1, gridBagConstraints);

        jMenu1.setText("Aplicación");

        jMenuItem1.setText("Cerrar");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Entrenamiento");

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("Elegir Entrenamiento");
        jCheckBoxMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxMenuItem1ActionPerformed(evt);
            }
        });
        jMenu2.add(jCheckBoxMenuItem1);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jCheckBoxMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxMenuItem1ActionPerformed
        
    }//GEN-LAST:event_jCheckBoxMenuItem1ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
       
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
    }//GEN-LAST:event_jButton1ActionPerformed

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
